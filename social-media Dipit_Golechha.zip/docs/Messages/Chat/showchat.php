<?php
session_start();


$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

if(empty($_SESSION["username"])){
     echo '<script>alert("Register or Log in first")</script>'; 
               echo "<script type='text/javascript'>window.open('Loginandsignup.php','_self');</script>";
    $Welcomemessage="Please Register or Log in";
    $link= "Loginandsignup.php";
   }else{
       $Welcomemessage= "Welcome Back " .$_SESSION["username"]. "" ;
           $link= "Person.php";

   }
   
   if(empty($_SESSION["nameofchat"])){
     echo '<script>alert("Select the chatname first")</script>'; 
               echo "<script type='text/javascript'>window.open('Message.php','_self');</script>";
   }
   
   
        $currentusername= $_SESSION['username'];
        $nameofthechat=  $_SESSION["nameofchat"];

$sql1 = "SELECT * FROM messaging WHERE Nameofthechat='$nameofthechat'";
$result1 = $connect->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
        $Forusername= $row1["For_Username"];
        $Createdby= $row1["Created_By"];
    }
}

$currentusername= $_SESSION['username'];
if ($Forusername==$currentusername) {
    $rightsidename= $currentusername;
    $chatwith= $Createdby;
} else {
    $leftsidename= $currentusername;
    $chatwith=$Forusername;
}


$Welcomemessage= "Welcome Back " .$_SESSION["username"]. "" ;
           $link= "Person.php";
        ?>

<html>
    <head>
<script
  src="https://code.jquery.com/jquery-3.2.1.js"
  integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
  crossorigin="anonymous"></script>
        <meta charset= UTF-8>
        <link rel ="stylesheet" href="style.css" /> <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
   <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <link href="../../assets/css/toolkit.css" rel="stylesheet">
    
    <link href="../../assets/css/application.css" rel="stylesheet">
   <script>
       $(document).foundation();

$(function() {
  $('.button-like')
    .bind('click', function(event) {
      $(".button-like").toggleClass("liked");
    })
});
   </script>
        <style>
        
      @import url('https://fonts.googleapis.com/css?family=Roboto:700&display=swap');
@import url(http://fonts.googleapis.com/css?family=Capriola);

                        *{
                padding:0px;
                margin: 0px;
            }
            #wrapper{
                width: 1000px;
                margin: 10px auto;
                background: #A9A9A9;
                padding: 20px;
            }
            
            .chat_wrapper{
              width: 70%;
               margin: 10px auto;
               background: white;

            }
            
        #chat{
          min-height: 500px;
          height: 500px;
          overflow: auto;
          border: 1px solid #bcb3b3;
          padding: 10px;

        }
        
        .textarea{
            width: 96%;
            border: 1px solid #b3b3b3;
            outline:none;
            padding: 10px;
            margin-top: 10px;
        }
        
        
        
        
        .single-message{
            padding: 5px 0px 5px 0px;
            border-bottom: 1px solid #b3b3b3;
        }
        .single-message span{
            float:right;
            
        }
        .h2{
        }


  
        </style>
    </head>
    <body>
            <div id='cssmenu'>
<ul>
   <li class='last'><a href='Feed.php'><span>Feed</span></a></li>
   <li class='last'><a href='AddPost.php'><span>Add Post</span></a></li>
   <li class='last'><a href='Message.php'><span>Message</span></a></li>
   <li class='last'><a href='Loginandsignup.php'><span>Login/Sign-up</span></a></li>
   <li class='last'><a href='Contactus.php'><span>Contact</span></a></li>
   <li class='last'><a href='<?php  echo $link; ?>'><span><?php echo $Welcomemessage; ?> </span></a></li>
</ul>
</div>

        <center>
<h2>
    <?php echo "You are chatting with: " .$chatwith."" ?>
</h2></center>
        <div id="wrapper">
            <div class="chat_wrapper">
                
                <div id="chat"></div>
                <form method="POST" id="messageForm">
                <textarea name="message" id="message" cols="30" rows="7"
                class="textarea"></textarea>
                </form>
                
            </div>
        </div>
        <script>
        
    LoadChat();
        
        setInterval(function(){
                LoadChat();
        },1000);
        function LoadChat(){
            
            $.post('messages.php?action=getMessages', function(response){
                
                var scrollpos = $('#chat').scrollTop();
                var scrollpos = parseInt(scrollpos) +520;
                var scrollHeight = $('#chat').prop('scrollHeight');

                
                $('#chat').html(response);
                
                if(scrollpos< scrollHeight){
                    
                }else{
                $('#chat').scrollTop( $('#chat').prop('scrollHeight'))
                }
            });
        }

        
        /// if enter key is preseed perform the function
            $('.textarea').keyup(function(e){
                if( e.which == 13){
                    $('form').submit();
                                    $('#chat').scrollTop( $('#chat').prop('scrollHeight'))

                }
            });
            
            
            $('form').submit(function(){
            var message = $(' .textarea').val();
              $.post('messages.php?action=sendMessage&message='+message, function(response){
                  if( response==1){
                      document.getElementById('messageForm').reset();
                  }
                   LoadChat();
                  
              });
              
              
                return false; ///so that the page doesn't refreses
            });
        </script>
                   <center>
               <br><br><br><br><br><br>
           <p1>You are using a website made by DIPIT GOLECHHA</p1>
</center>

    </body>
</html>