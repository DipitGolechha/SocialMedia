<?php
session_start();


$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

if(empty($_SESSION["username"])){
     echo '<script>alert("Register or Log in first")</script>';
               echo "<script type='text/javascript'>window.open('https://dipitpractice.000webhostapp.com/MemeOMania/docs/login/','_self');</script>";
   }
   
            $Currentusername= $_SESSION["username"];
            $chatid= $_GET["Id"];
             $_SESSION["idofchat"]= $chatid;


   $check= "Select * from Messages Where Id = $chatid";
   $result = mysqli_query($connect, $check); 
                while($row = mysqli_fetch_array($result))  
                {
                    if($row["Username1"]== $Currentusername){
                        $chatusername = $row["Username2"];
                        $chatwith= $chatusername;
                    }else if($row["Username2"]== $Currentusername){
                        $chatusername = $row["Username1"];
                        $chatwith= $chatusername;
                    }else{
                             echo '<script>alert("Stop reading others chat you dumbo")</script>';
                         echo "<script type='text/javascript'>window.open('https://dipitpractice.000webhostapp.com/MemeOMania/docs/login/','_self');</script>";

                    }
                }


?>

<html>
    <head>
<script
  src="https://code.jquery.com/jquery-3.2.1.js"
  integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
  crossorigin="anonymous"></script>
        <meta charset= UTF-8>
        <link rel ="stylesheet" href="style.css" /> <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
   <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <link href="../../assets/css/toolkit.css" rel="stylesheet">
    
    <link href="../../assets/css/application.css" rel="stylesheet">
   <script>
       $(document).foundation();

$(function() {
  $('.button-like')
    .bind('click', function(event) {
      $(".button-like").toggleClass("liked");
    })
});
   </script>
        <style>
        
      @import url('https://fonts.googleapis.com/css?family=Roboto:700&display=swap');
@import url(http://fonts.googleapis.com/css?family=Capriola);

                        *{
                padding:0px;
                margin: 0px;
            }
            #wrapper{
                width: 900px;
                margin: 10px auto;
                background: #A9A9A9;
                padding: 20px;
            }
            
            .chat_wrapper{
              width: 80%;
               margin: 10px auto;
               background: white;
            }
            
        #chat{
          min-height: 500px;
          height: 500px;
          overflow: auto;
          border: 1px solid #bcb3b3;
          padding: 10px;

        }
        
        .textarea{
            width: 100%;
            border: 1px solid #b3b3b3;
            outline:none;
            padding: 10px;
            margin-top: 10px;
            height: 100px;
        }
        </style>
    </head>
    <body>
    
   
        <center>
<h2>
    <?php echo "You are chatting with: " .$chatwith."" ?>
</h2></center>
        <div id="wrapper">
            <div class="chat_wrapper">
                
                <div id="chat"></div>
                <form method="POST" id="messageForm">
                <textarea name="message" id="message" cols="30" rows="7"
                class="textarea"></textarea>
                </form>
                
            </div>
        </div>
        <script>
        
    LoadChat();
        
        setInterval(function(){
                LoadChat();
        },1000);
        function LoadChat(){
            
            $.post('messages.php?action=getMessages', function(response){
                
                var scrollpos = $('#chat').scrollTop();
                var scrollpos = parseInt(scrollpos) +520;
                var scrollHeight = $('#chat').prop('scrollHeight');

                
                $('#chat').html(response);
                
                if(scrollpos< scrollHeight){
                    
                }else{
                $('#chat').scrollTop( $('#chat').prop('scrollHeight'))
                }
            });
        }

        
        /// if enter key is preseed perform the function
            $('.textarea').keyup(function(e){
                if( e.which == 13){
                    $('form').submit();
                                    $('#chat').scrollTop( $('#chat').prop('scrollHeight'))

                }
            });
            
            
            $('form').submit(function(){
            var message = $(' .textarea').val();
              $.post('messages.php?action=sendMessage&message='+message, function(response){
                  if( response==1){
                      document.getElementById('messageForm').reset();
                  }
                   LoadChat();
                  
              });
              
              
                return false; ///so that the page doesn't refreses
            });
        </script>
                   <center>
               <br><br><br><br><br><br>
           <p1>You are using a website made by DIPIT GOLECHHA</p1>
</center>

    </body>
</html>