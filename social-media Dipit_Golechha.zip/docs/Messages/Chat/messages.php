<?php

session_start();


$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

date_default_timezone_set('Asia/Kolkata');

   
switch($_REQUEST['action']){
    case "sendMessage":

       $message = $_REQUEST['message'];
       $username= $_SESSION['username'];
       $idofchat=  $_SESSION["idofchat"];
       

       
  $sql = "INSERT INTO `$idofchat`(Username,Message) VALUES ('$username','$message')";
  
  if ($connect->query($sql) === TRUE) {
      echo '1';
      exit;
  }else{
    echo '0';
    exit;
}    break;



      case "getMessages":
       $idofchat=  $_SESSION["idofchat"];
       $username= $_SESSION["username"];
       
         $getmessages = "SELECT * FROM `$idofchat`";
         $allmessages = $connect->query($getmessages);

    if ($allmessages->num_rows >= 0) {
    while($row = $allmessages->fetch_assoc()) {
        echo '<ul class="media-list media-list-conversation c-w-md">';
        if($row['Username']=="$username"){
            $Username= $_SESSION["username"];
                $query2 = "SELECT * FROM Information WHERE Username='$Username' ";                
                $result2 = mysqli_query($connect, $query2);  
                                while($row2 = mysqli_fetch_array($result2))  {
            echo '
            
             <li class="media media-current-user mb-4">
       <div class="media-body">
      <div class="media-body-text">'.$row["Message"].'
       </div>
      <div class="media-footer">
        <small class="text-muted">
          <a href="#">'.$row["Username"].'</a> at '.date('m-d-Y-h:i a',strtotime($row['Time'])).'
        </small>
      </div>
    </div>
    
    <img class="rounded-circle media-object ml-3" src="data:image/jpeg;base64,' .base64_encode($row2['ProfilePicture'] ).'">
  </li>
            
            ';

                                } 
        }else{
            
            $chatusername= $row["Username"];
            $query3 = "SELECT * FROM Information WHERE Username='$chatusername' ";                
                $result3 = mysqli_query($connect, $query3);  
                                while($row3 = mysqli_fetch_array($result3))  {
            echo '
            
              <li class="media mb-4">
              
              
        <img class="rounded-circle media-object ml-3" src="data:image/jpeg;base64,' .base64_encode($row3['ProfilePicture'] ).'">

    
    <div class="media-body">
      <div class="media-body-text">'. $row["Message"].'

      </div>
      <div class="media-footer">
        <small class="text-muted">
          <a href="#">'.$row["Username"].' </a> at '.date('m-d-Y-h:i a',strtotime($row['Time'])).'
        </small>
      </div>
    </div>
  </li>
            
            
            ';
            
            
            

       } }
    
    

}}
    break;
    
}
?>
