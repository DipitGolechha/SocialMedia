<?php
session_start();


$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

if(empty($_SESSION["username"])){
     echo '<script>alert("Register or Log in first")</script>'; 
               echo "<script type='text/javascript'>window.open('Loginandsignup.php','_self');</script>";
    $Welcomemessage="Please Register or Log in";
    $link= "Loginandsignup.php";
   }else{
       $Welcomemessage= "Welcome Back " .$_SESSION["username"]. "" ;
           $link= "Person.php";
      $username= $_SESSION["username"];
   }

$sql = "SELECT Name FROM Login WHERE Username='$username' ";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $name= $row["Name"];
        $_SESSION["name"]=$name;
    }
} 

$sql = "SELECT Email FROM Login WHERE Username='$username' ";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $Email= $row["Email"];
        $_SESSION["email"]=$Email;
    }
} 


?>

<?php
 if(isset($_POST["showchat"]))  {
    $_SESSION["nameofchat"]= $_POST['Nameofchat'];
        echo "<script type='text/javascript'>window.open('showchat.php','_self');</script>";
 }

 if(isset($_POST["startchat"]))  {
     $Nameofthechat= $_POST['chatname'];
     $For= $_POST['Username'];
     $Creator= $_SESSION["username"];

$createtable= "CREATE TABLE `id12308990_dipit`.`$Nameofthechat` ( `username` VARCHAR(255) NOT NULL , `message` TEXT NOT NULL , `date` TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) )";

if ($connect->query($createtable) === TRUE) {
    $message2= "New table Created successfully";
    echo "<script type='text/javascript'>alert('$message2');</script>";
 } else{
     $message2= "There is a error";
    echo "<script type='text/javascript'>alert('$message2');</script>";
 }
 
$createme = "INSERT INTO messaging (Nameofthechat,For_Username,Created_By)
VALUES ('$Nameofthechat','$For','$Creator')"; 

if ($connect->query($createme) === TRUE) {
    $message= "New Chat Created successfully";
    echo "<script type='text/javascript'>alert('$message');</script>";
} else{
  $Message= "There is a error, redricting you to the login page";
    echo "<script type='text/javascript'>alert('$Message');</script>";
   echo "<script type='text/javascript'>window.open('Loginandsignup.php','_self');</script>";
}
}
?>



<html>
    <head>
            <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
           <link rel="stylesheet" href="Message.css" />  

        <style>
        
      @import url('https://fonts.googleapis.com/css?family=Roboto:700&display=swap');
@import url(http://fonts.googleapis.com/css?family=Capriola);
#cssmenu,
#cssmenu ul,
#cssmenu ul li,
#cssmenu ul li a {
  margin: 0;
  padding: 0;
  border: 0;
  list-style: none;
  line-height: 1;
  display: block;
  position: relative;
  font-family: Capriola, Helvetica, sans-serif;
}
#cssmenu {
  width: auto;
  height: 59px;
  padding-bottom: 4px;
}
#cssmenu.align-right {
  float: right;
}
#cssmenu.align-right ul li {
  float: right;
  margin-right: 0;
  margin-left: 4px;
}
#cssmenu.align-right ul li:first-child,
#cssmenu.align-right ul li:first-child > a {
  border-bottom-right-radius: 3px;
}
#cssmenu #bg-one,
#cssmenu #bg-two,
#cssmenu #bg-three,
#cssmenu #bg-four {
  position: absolute;
  bottom: 0;
  width: 100%;
  border-bottom-left-radius: 3px;
  border-bottom-right-radius: 3px;
}
#cssmenu #bg-one {
  height: 10px;
  background: #0f71ba;
}
#cssmenu #bg-two {
  height: 59px;
  z-index: 2;
  background: url('images/bg.png');
}
#cssmenu #bg-three {
  bottom: 4px;
  height: 55px;
  z-index: 3;
  background: #222222;
  background: -moz-linear-gradient(top, #555555 0%, #222222 100%);
  background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #555555), color-stop(100%, #222222));
  background: -webkit-linear-gradient(top, #555555 0%, #222222 100%);
  background: -o-linear-gradient(top, #555555 0%, #222222 100%);
  background: -ms-linear-gradient(top, #555555 0%, #222222 100%);
  background: linear-gradient(to bottom, #555555 0%, #222222 100%);
}
#cssmenu #bg-four {
  bottom: 4px;
  height: 55px;
  z-index: 4;
  background: url('images/bg.png');
}
#cssmenu ul {
  height: 59px;
}
#cssmenu ul li {
      float: left;
  margin-right: 4px;
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
  z-index: 5;
}
#cssmenu ul li a {
  padding: 24px 30px 20px 30px;
  margin-bottom: 4px;
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
  color: #eeeeee;
  font-size: 15px;
  text-decoration: none;
}
#cssmenu ul li:first-child,
#cssmenu ul li:first-child > a {
  border-bottom-left-radius: 3px;
}
#cssmenu ul li:hover,
#cssmenu ul li.active {
  background: #0f71ba;
  background: -moz-linear-gradient(top, #3fa4f0 0%, #0f71ba 100%);
  background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #3fa4f0), color-stop(100%, #0f71ba));
  background: -webkit-linear-gradient(top, #3fa4f0 0%, #0f71ba 100%);
  background: -o-linear-gradient(top, #3fa4f0 0%, #0f71ba 100%);
  background: -ms-linear-gradient(top, #3fa4f0 0%, #0f71ba 100%);
  background: linear-gradient(to bottom, #3fa4f0 0%, #0f71ba 100%);
}
#cssmenu ul li a:hover,
#cssmenu ul li.active > a {
  background: url('images/bg.png');
  color: #ffffff;
}
.button{
    border-radius:5px;
    padding:10px;
  background-image: linear-gradient(to right, #02aab0 , #00cdac);
    border: none;
    border-bottom: 5px solid #CB64B2;
    width:auto;
    height:auto;

  }

  .Usernames-list{
  background-image: linear-gradient(to right, #02aab0 , #00cdac);
    height:50px;
    width:320px;
    font-size:2px;
    color: black;
    font-size:15px;

}

      table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #04bbd4;
color: white;
}
tr{
    color: white;
}
tr:nth-child(even) {background-color: #FF5733}

.startachat-form {
    background: white;
    text-align: center;
    box-shadow: 0px 0px 20px 5px #AAA;
    border-radius: 10px;
    width: 45%;
    height: auto;
    margin: 30px auto 0 auto;
    padding: 10px 10px;
  }
  
  .form {
    background: #EBEBEB;
    text-align: center;
    box-shadow: 0px 0px 20px 5px #AAA;
    border-radius: 10px;
    width: 45%;
    height: 400px;
    margin: 30px auto 0 auto;
    padding: 10px 10px;
    animation: bounce 1.5s infinite;
  }
 
.content{
    padding: 100px;
}

  ::-webkit-input-placeholder{
      color: white;
      font-size: 20px;
  }




.submit{
    margin-bottom: 28px;
    width: 120px;
    height: 32px;
   background-image: linear-gradient(to right, #eb3349 , #f45c43);
    border: none;
    border-radius: 2px;
    color: #fff;
    font-family: sans-serif;
    font-weight: 500;
    text-transform: uppercase;
    transition: 0.2s ease;
    cursor: pointer;
    
}
  .chatname {
  background-image: linear-gradient(to right, #02aab0 , #00cdac);
    color: black;
   height:50px;
    width:320px;
        font-size:25px;

  }
  
  .h4{
  text-align: center;
      color: black;
      text: 50px;
      
  }
</style>
    </head>
    <body>
            <div id='cssmenu'>
<ul>
   <li class='last'><a href='Feed.php'><span>Feed</span></a></li>
   <li class='last'><a href='AddPost.php'><span>Add Post</span></a></li>
   <li class='active'><a href='Message.php'><span>Message</span></a></li>
   <li class='last'><a href='Loginandsignup.php'><span>Login/Sign-up</span></a></li>
   <li class='last'><a href='Contactus.php'><span>Contact</span></a></li>
   <li class='last'><a href='<?php  echo $link; ?>'><span><?php echo $Welcomemessage; ?> </span></a></li>
</ul>
</div>

<form class="startachat-form" method="POST">
    <h1> START A CHAT NOW </h1>
    <h2>Write the chatname you want to keep</h2>
    <input type=text class="chatname" name="chatname" id="chatname" placeholder="Enter Chatname" required>
        <h2>Choose the username you want to start chat with</h2>
        
<input list="Username" class="Usernames-list" name="Username"  placeholder="Select the Username" required>
  <datalist id="Username" placeholder="Select Username">
       <?php
    $selectusername = "SELECT * FROM Login";
            $result2 =$connect->query($selectusername);
if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
        echo "<option value=". $row2["Username"] . ">";
    }
}  ?>
  </datalist>
    <br>
    <button class="submit entry" name="startchat" id="startchat" value="startchat"> Start Chat</button>

</form>


<form class="startachat-form" method="POST">
    <h1> Open A CHAT NOW </h1>
        <h2>Choose the Name of the chat you want to open</h2>
<input list="Nameofchat" class="Usernames-list" name="Nameofchat"  placeholder="Select the name of the chat" required>
  <datalist id="Nameofchat" placeholder="Select Name of the Chat">
          <?php
    $selectNameofthechat = "SELECT * FROM messaging Where For_Username='$username' || Created_By='$username' ";
            $output =$connect->query($selectNameofthechat);
if ($output->num_rows > 0) {
    // output data of each row
    while($row1 = $output->fetch_assoc()) {
        echo "<option value=". $row1["Nameofthechat"].  ">";
    }
}  ?>
  </datalist>
    <br>
              <button class="submit entry" name="showchat" id="showchat" value="showchat"> Show Chat</button>
</form>
<center>        <h1>Your Chats</h1>
</center>

<table>
        <tr>
            <th>Name of the Chat</th>
            <th>For</th>
            <th>Created By</th>
            <?php
$sql = "SELECT * FROM messaging Where For_Username='$username' || Created_By='$username' ";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
         echo "<tr><td> " . $row["Nameofthechat"]. "</td><td>" . $row["For_Username"] . "</td><td>". $row["Created_By"]. "</td> ";
}
    echo "</table>";
} 
?>

</table>


</table>
           <center>
               <br><br><br><br><br><br>
           <p1>You are using a website made by DIPIT GOLECHHA</p1>
</center>
</body>
</html>