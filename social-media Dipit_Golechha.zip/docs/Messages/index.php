<?php
session_start();


$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

if(empty($_SESSION["username"])){
     echo '<script>alert("Register or Log in first")</script>';
               echo "<script type='text/javascript'>window.open('https://dipitpractice.000webhostapp.com/MemeOMania/docs/login/','_self');</script>";
   }
   
            $Username= $_SESSION["username"];
            
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Messages &middot;
      
    </title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <link href="../assets/css/toolkit.css" rel="stylesheet">
    
    <link href="../assets/css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
    </style>

  </head>


<body class="with-top-navbar">
<nav class="navbar navbar-toggleable-sm fixed-top navbar-inverse bg-primary app-navbar">
  <button
    class="navbar-toggler navbar-toggler-right hidden-md-up"
    type="button"
    data-toggle="collapse"
    data-target="#navbarResponsive"
    aria-controls="navbarResponsive"
    aria-expanded="false"
    aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <a class="navbar-brand" href="#">
    <img src="../assets/img/brand-title.png" alt="brand">
  </a>

  <div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="../">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="modal" href="">Messages</a>
      </li>
      <li class="nav-item hidden-md-up">
        <a class="nav-link" href="#">Notifications</a>
      </li>
      <li class="nav-item hidden-md-up">
        <a class="nav-link" href="../login/">Logout</a>
      </li>

    </ul>

    <form class="form-inline float-right hidden-sm-down">
      <input class="form-control" type="text" data-action="grow" placeholder="Search">
    </form>

    <ul id="#js-popoverContent" class="nav navbar-nav float-right mr-0 hidden-sm-down">
      <li class="nav-item">
        <a class="app-notifications nav-link" href="#">
          <span class="icon icon-bell"></span>
        </a>
      </li>
      <li class="nav-item ml-2">
        <button class="btn btn-default navbar-btn navbar-btn-avatar" data-toggle="popover">
            <?php
            $Username= $_SESSION["username"];
                $query2 = "SELECT * FROM Information WHERE Username='$Username' ";                
                $result2 = mysqli_query($connect, $query2);  
                                while($row2 = mysqli_fetch_array($result2))  {
            
            echo '
<img src="data:image/jpeg;base64,' .base64_encode($row2['ProfilePicture'] ).'" class="rounded-circle" />' ;
   
   
   }
   ?>    </button>
      </li>
    </ul>

    <ul class="nav navbar-nav hidden-xs-up" id="js-popoverContent">
      <li class="nav-item"><a class="nav-link" href="login/">Logout</a></li>
    </ul>
  </div>
</nav>



  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Messages</h5>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>

      <div class="modal-body p-0 js-modalBody">
        <div class="modal-body-scroller">
          <div class="media-list media-list-users list-group js-msgGroup">
              
               <?php
              $currentusername= $_SESSION["username"];
              
              $sql= "SELECT * From Messages WHERE Username1 = '$currentusername' or Username2 = '$currentusername'";
               $result = mysqli_query($connect, $sql);
               while($row = mysqli_fetch_array($result))  {
                   
                   if($row["Username1"]== $currentusername) {
                       $chooserow=2;
                   } 
                   
                   if($row["Username2"]== $currentusername){
                       $chooserow=1;
                   }
                   
                   
                   if($chooserow=1){
                       if($row["Username1"]== $currentusername ){
                           
                       }else{
                       $chatusername= $row["Username1"];
                  
                   }} 
                   
                   if($chooserow=2){
                       if($row["Username2"]== $currentusername){
                           
                       }else{
                     $chatusername= $row["Username2"];

                   }}
                   
                     $newsql= "Select * From Information Where Username = '$chatusername'";
                      $result1 = mysqli_query($connect, $newsql);
                      
               while($row1 = mysqli_fetch_array($result1)){
                  
              ?>
              
              
            <a href="Chat/?Id=<?php echo $row["Id"];?>"  class="list-group-item list-group-item-action">
              <div class="media">
                  <?php
                  echo '
                   <img class="rounded-circle media-object d-flex align-self-start mr-3" height="42" width="42"
                   src="data:image/jpeg;base64,' .base64_encode($row1['ProfilePicture'] ).'">
                  '
                  ?>
               
                <div class="media-body">
                  <strong> <?php echo $chatusername ?></strong>  <strong></strong>
                  <div class="media-body-secondary">
                    <?php  echo $row["Lastmessage"] ?> &hellip;
                  </div>
                </div>
              </div>
            </a>

            <?php 
            
               }}
               ?>

          </div>


    <script>
      // execute/clear BS loaders for docs
      $(function(){
        if (window.BS&&window.BS.loader&&window.BS.loader.length) {
          while(BS.loader.length){(BS.loader.pop())()}
        }
      })
    </script>
  </body>
</html>

