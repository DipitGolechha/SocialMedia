

<!DOCTYPE html>
<html lang="en">
  <head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Login &middot; 
      
    </title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <link href="../assets/css/toolkit.css" rel="stylesheet">
    
    <link href="../assets/css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
    </style>

  </head>

<body>
 
<div class="container-fluid container-fill-height">
  <div class="container-content-middle">
    <form role="form" class="mx-auto text-center app-login-form" Action="Login.php" Method="POST">

      <a href="../index.php" class="app-brand mb-5">
        <img src="../assets/img/brand.png" alt="brand">
      </a>

      <div class="form-group">
        <input type="text" class="form-control" placeholder="Username" id="Username" name="Username" required>
      </div>

      <div class="form-group mb-3">
        <input type="password" class="form-control" placeholder="Password" id="Password" name="Password" required>
      </div>
      
      <div class="mb-5">
        <button class="btn btn-primary"  name="login_button" id="login_button" >Log In</button>
         <input type="button" onclick="location.href='../SignUp';" class="btn btn-secondary" value="Sign up">
      </div>

      <footer class="screen-login">
        <a href="#" class="text-muted">Forgot password</a>
      </footer>
    </form>
  </div>
</div>


    <script src="../assets/js/jquery.min.js"></script>    
    <script src="../assets/js/tether.min.js"></script>
    <script src="../assets/js/chart.js"></script>
    <script src="../assets/js/toolkit.js"></script>
    <script src="../assets/js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){
        if (window.BS&&window.BS.loader&&window.BS.loader.length) {
          while(BS.loader.length){(BS.loader.pop())()}
        }
      })
    </script>
  </body>
</html>

