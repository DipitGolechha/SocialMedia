<?php
session_destroy();




?>
<html>
    <body>
        <script>
            window.open("index.html");
        </script>
    </body>
</html>