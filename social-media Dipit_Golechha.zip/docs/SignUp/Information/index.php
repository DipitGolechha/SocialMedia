<?php

session_start();

$servername = "localhost";
$username = "id12308990_dipitgolechha";
$password = "R[N&H]3=F&A!frM|";
$dbname = "id12308990_new_socialmedia";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

if(isset($_POST["signup_button"])) {
      $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
      $user_username= $_SESSION["username"];
      $user_DateOfBirth= $_POST["birthday"];
      $user_Hobbies= $_POST["Hobbies"];
      $user_Relationship_status= $_POST["radio-group"];
      $user_Lives_in= $_POST["Lives_in"];
      $user_From_place= $_POST["From_place"];
      $user_Bio= $_POST["Bio"];
                 
                 
        $sql= " Insert Into Information(Username,DateOfBirth,Relationship_status,Hobbies,Lives_in,From_place,Bio,ProfilePicture,Friends,Enemies) Values('$user_username','$user_DateOfBirth','$user_Relationship_status','$user_Hobbies','$user_Lives_in','$user_From_place','$user_Bio','$file',0,0);";
        
        
if ($connect->query($sql) === TRUE) {
                   echo '<script>  window.open("../../","_self"); </script>';

}else{
    $message = "Fail attempt try again";
    echo "<script type='text/javascript'>alert('$message');</script>";
}

}
 


?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Sign Up &middot; 
      
    </title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <link href="../../assets/css/toolkit.css" rel="stylesheet">
    
    <link href="../../assets/css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
   [type="radio"]:checked,
[type="radio"]:not(:checked) {
    position: absolute;
    left: -9999px;
}
[type="radio"]:checked + label,
[type="radio"]:not(:checked) + label
{
    position: relative;
    padding-left: 28px;
    cursor: pointer;
    line-height: 20px;
    display: inline-block;
    color: #666;
}
[type="radio"]:checked + label:before,
[type="radio"]:not(:checked) + label:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 18px;
    height: 18px;
    border: 1px solid #ddd;
    border-radius: 100%;
    background: #fff;
}
[type="radio"]:checked + label:after,
[type="radio"]:not(:checked) + label:after {
    content: '';
    width: 12px;
    height: 12px;
    background: #3097D1;
    position: absolute;
    top: 4px;
    left: 4px;
    border-radius: 100%;
    -webkit-transition: all 0.2s ease;
    transition: all 0.2s ease;
}
[type="radio"]:not(:checked) + label:after {
    opacity: 0;
    -webkit-transform: scale(0);
    transform: scale(0);
}
[type="radio"]:checked + label:after {
    opacity: 1;
    -webkit-transform: scale(1);
    transform: scale(1);
}
input[type="file"] {
    display: none;
}
    </style>

  </head>

<body>
 <script>
 $(document).ready(function(){
      $('#insert').click(function(){
           var image_name = $('#image').val();
           if(image_name == '')
           {
                alert("Please Select Image");
                return false;
           }
           else
           {
                var extension = $('#image').val().split('.').pop().toLowerCase();
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
                {
                     alert('Invalid Image File');
                     $('#image').val('');
                     return false;
                }
           }
      });
 });
 </script> 
 <br><br>
<div class="container-fluid container-fill-height">
  <div class="container-content-middle">
    <form  enctype="multipart/form-data" role="form" class="mx-auto text-center app-login-form" Method="POST">

      <a href="../../index.php" class="app-brand mb-5">
        <img src="../../assets/img/brand.png" alt="brand">
      </a>

      <div class="form-group">
 <label for="birthday">Birthday:</label>
  <input type="date" id="birthday" name="birthday">
  </div>
  
       <label for="Relationship_status">Your Relationship Status:</label>
         <p>
    <input type="radio" id="1" name="radio-group" value="Single" checked>
    <label for="1">Single</label>
  </p>
  <p>
    <input type="radio" id="2" name="radio-group" value="In a relationship">
    <label for="2">In a relationship</label>
  </p>
 
          

      <div class="form-group mb-3">
        <input type="int" class="form-control" placeholder="Enter Hobbies" id="Hobbies" name="Hobbies" >
      </div>
      
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Where do you live?" id="Lives_in" name="Lives_in" >
      </div>
      
      <div class="form-group mb-3">
        <input type="text" class="form-control" placeholder="Where are you from?" id="From_place" name="From_place" >
      </div>
      
            <div class="form-group mb-3">
        <input type="text" class="form-control" placeholder="Enter your Bio" id="Bio" name="Bio">
      </div>

            <div class="form-group mb-3">
       <label for="image" class="btn btn-secondary">
            <span class="icon icon-camera"></span> <center>Add ProfilePicture</center>
           </label>
            <input type="file" id="image" name="image"  required/>
      
      </div>
      
      <div class="mb-5">
           <button class="btn btn-primary"  name="signup_button" id="signup_button" >Sign Up</button>
         <input type="button" onclick="location.href='../../login';" class="btn btn-secondary" value="Login">
      </div>
    </form>
  </div>
</div>


    <script src="../../assets/js/jquery.min.js"></script>    
    <script src="../../assets/js/tether.min.js"></script>
    <script src="../../assets/js/chart.js"></script>
    <script src="../../assets/js/toolkit.js"></script>
    <script src="../../assets/js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){
        if (window.BS&&window.BS.loader&&window.BS.loader.length) {
          while(BS.loader.length){(BS.loader.pop())()}
        }
      })
    </script>
</body>
</html>

