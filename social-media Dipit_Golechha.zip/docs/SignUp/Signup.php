<?php
session_start();
session_destroy();
session_start();

$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

 if(isset($_POST["signup_button"])) {


$user_username= $_POST['Username'];
$user_password= $_POST['Password'];
$user_email= $_POST['Email'];


$sql = " Insert Into Login(Username,Password,Email) Values('$user_username','$user_password','$user_email')";
if ($connect->query($sql) === TRUE) {    
              $_SESSION["username"]= $user_username;
               echo '<script>  window.open("../SignUp/Information","_self"); </script>';
            
}else{
    $message = "Fail attempt try again";
    echo "<script type='text/javascript'>alert('$message');</script>";
                   echo '<script>  window.open("../SignUp","_self"); </script>';  

}


}
?>

<html>
    
    <head>
         <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
</html>