<?php
session_start();

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);


switch($_REQUEST['action']){
    case "LikePost":
        


        $post_id = $_REQUEST['post_id'];
       $Username= $_SESSION["username"];
      
        $insert = "INSERT INTO Posts_Likes(User_Username,Post_id) VALUES ('$Username','$post_id')";
        
         if ($connect->query($insert) === TRUE) {
             
             
             $select= "SELECT * FROM All_Posts Where Id='$post_id'";
             $addlikeresult = mysqli_query($connect, $select);  
             while($row = mysqli_fetch_array($addlikeresult)){
                 $nooflikesnumber= $row["Nooflikes"];
                 $newlikes= $nooflikesnumber +1; 
                              $updatelike= "Update All_Posts SET Nooflikes='$newlikes' WHERE Id='$post_id'"; 
                              
                              $increaselikeresult = mysqli_query($connect, $updatelike);  ;
                }
             
             
             
      exit;
  }else{
    echo "Error";
    exit;
}    break;


} 
?>