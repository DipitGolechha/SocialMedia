<?php
session_start();


$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$connect = new mysqli($servername, $username, $password, $dbname);

            $Username= $_SESSION["username"];
                $query2 = "SELECT * FROM Information WHERE Username='$Username' ";                
                $result2 = mysqli_query($connect, $query2);  
                                while($row2 = mysqli_fetch_array($result2))  {
            
            
                        $ProfilePicture= base64_encode($row2['ProfilePicture'] );
   
   
   }
   


if(empty($_SESSION["username"])){
     echo '<script>alert("Register or Log in first")</script>';
               echo "<script type='text/javascript'>window.open('https://dipitpractice.000webhostapp.com/MemeOMania/docs/login/','_self');</script>";
   }else{
       
       echo ' <br>
    <div class="alert alert-success alert-dismissible" id="myAlert">
    <a href="#" class="close">&times;</a>
    <strong>Success!</strong> You have succesfully logged in.
  </div>
  
   <div class="alert alert-success alert-dismissible" id="myAlert">
    <a href="#" class="close">&times;</a>
    <strong>Welcome Back!</strong> ' ; echo $Username; echo '
  </div>
  
    ';
    
    
            echo '<script>
            
            setInterval(function(){ 
    $("#myAlert").alert("close");
}, 
3000);
           
            
     
            
            </script>';



   }




$session_username= $_SESSION["username"];


if(isset($_POST["insert"]))
 {
      $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
      $Caption= $_POST['Caption'];
      $username= $_SESSION['username'];
      $query = "INSERT INTO All_Posts(Username,Img,Text,Nooflikes)
      VALUES ('$username','$file','$Caption',0)";
      if(mysqli_query($connect, $query))
      {
           echo '<script>alert("Your post is live")</script>';

      }  else{
                     echo '<script>alert("There is an error, try again :)")</script>';

      }
 }

$currentUsername= $_SESSION["username"];
            $selectdetails= "SELECT * FROM Information WHERE Username='$currentUsername'";
            $resultofselectdetails = mysqli_query($connect,$selectdetails);
            if($resultofselectdetails->num_rows ==1){
                   while($row = mysqli_fetch_array($resultofselectdetails))  
                   {
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>
      
        Home &middot;
      
    </title>

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
    <link href="assets/css/toolkit.css" rel="stylesheet">
    
    <link href="assets/css/application.css" rel="stylesheet">

    <style>
      /* note: this is a hack for ios iframe for bootstrap themes shopify page */
      /* this chunk of css is not part of the toolkit :) */
      body {
        width: 1px;
        min-width: 100%;
        *width: 100%;
      }
      
      a.likebutton {
	background-color: #3097D1;
  color: white;
    padding: 1em 1.5em;
  position: relative;
  text-decoration: none;
  text-transform: uppercase;
}

a.likebutton:hover {
  background-color: #2e81b0;
  cursor: pointer;
}


a.likebutton:active {
  box-shadow: none;
  top: 5px;
}

.addpostbutton {
	background-color: #FFFFFF;
  color: black;
  height:30%;
      padding: 1em 1em;
  text-decoration: none;
  text-transform: uppercase;
}

.addpostbutton:hover {
  background-color: #FFFFFF;
  cursor: pointer;
}


.addpostbutton:active {
  box-shadow: none;
  top: 5px;
}

.numberCircle {
    width: auto;
    height: auto;
    
    background: #fff;
    border: 2px solid #3097D1;
    color: #3097D1;
    text-align: center;

    font: 32px Arial, Bold;
}

input[type="file"] {
    display: none;
}

.btn-secondary1 {
  color: #292b2c;
  background-color: #add8e6;
  border-color: #ccc; }
  .btn-secondary1:hover {
    color: #292b2c;
    background-color: #7cc6de;
    border-color: #adadad; }
  .btn-secondary1:focus, .btn-secondary1.focus {
    box-shadow: 0 0 0 2px rgba(204, 204, 204, 0.5); }
  .btn-secondary1.disabled, .btn-secondary1:disabled {
    background-color: #add8e6;
    border-color: #ccc; }
  .btn-secondary1:active, .btn-secondary1.active,
  .show > .btn-secondary1.dropdown-toggle {
    color: #292b2c;
    background-color: #add8e6;
    background-image: none;
    border-color: #adadad; }
    
    .form-control1 {
  display: block;
  width: 100%;
  padding: 0.5rem 0.75rem;
  font-size: 1rem;
  line-height: 1.25;
  color: #464a4c;
  background-color: #add8e6;
  background-image: none;
  background-clip: padding-box;
  border: 1px solid rgba(0, 0, 0, 0.15);
  border-radius: 0.25rem;
  -webkit-transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s;
  transition: border-color ease-in-out 0.15s, box-shadow ease-in-out 0.15s; }
    </style>

  </head>
 <script>
 $(document).ready(function(){
      $('#insert').click(function(){
           var image_name = $('#image').val();
           if(image_name == '')
           {
                alert("Please Select Image");
                return false;
           }
           else
           {
                var extension = $('#image').val().split('.').pop().toLowerCase();
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
                {
                     alert('Invalid Image File');
                     $('#image').val('');
                     return false;
                }
           }
      });
 });
 </script>

    <script type="text/javascript">
  function reply_click(clicked_id)
  {
      var post_id = clicked_id;
       $.post('likepost.php?action=LikePost&post_id='+post_id);
  }
</script>
<script>
$(document).ready(function(){
  $(".close").click(function(){
    $("#myAlert").alert("close");
  });
});


</script>
</script>
<body class="with-top-navbar">



<nav class="navbar navbar-toggleable-sm fixed-top navbar-inverse bg-primary app-navbar">
  <button
    class="navbar-toggler navbar-toggler-right hidden-md-up"
    type="button"
    data-toggle="collapse"
    data-target="#navbarResponsive"
    aria-controls="navbarResponsive"
    aria-expanded="false"
    aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <a class="navbar-brand" href="#">
    <img src="assets/img/brand-title.png" alt="brand">
  </a>

  <div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="modal" href='../docs/Messages'>Messages</a>
      </li>
      <li class="nav-item hidden-md-up">
        <a class="nav-link" href="#">Notifications</a>
      </li>
      <li class="nav-item hidden-md-up">
        <a class="nav-link" href="login/index.php">Logout</a>
      </li>

    </ul>

    <form class="form-inline float-right hidden-sm-down">
      <input class="form-control" type="text" data-action="grow" placeholder="Search">
    </form>

    <ul id="#js-popoverContent" class="nav navbar-nav float-right mr-0 hidden-sm-down">
      <li class="nav-item">
        <a class="app-notifications nav-link" href="#">
          <span class="icon icon-bell"></span>
        </a>
      </li>
      <li class="nav-item ml-2">
        <button class="btn btn-default navbar-btn navbar-btn-avatar" data-toggle="popover">
            <?php
            $Username= $_SESSION["username"];
                $query2 = "SELECT * FROM Information WHERE Username='$Username' ";                
                $result2 = mysqli_query($connect, $query2);  
                                while($row2 = mysqli_fetch_array($result2))  {
            
            echo '
<img src="data:image/jpeg;base64,' .base64_encode($row2['ProfilePicture'] ).'" class="rounded-circle" />' ;
   
   
   }
   ?>    </button>
      </li>
    </ul>

    <ul class="nav navbar-nav hidden-xs-up" id="js-popoverContent">
      <li class="nav-item"><a class="nav-link" href="login/">Logout</a></li>
    </ul>
  </div>
</nav>



<div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Users</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>

    </div>
  </div>
</div>


<div class="container pt-4">
  <div class="row">
    <div class="col-lg-3">
      <div class="card card-profile mb-4">
        <div class="card-header" style="background-image: url(assets/img/iceland.jpg);"></div>
        <div class="card-block text-center">
          <a href="profile/index.html">
              <?php
            $Username= $_SESSION["username"];
                $query2 = "SELECT * FROM Information WHERE Username='$Username' ";                
                $result2 = mysqli_query($connect, $query2);  
                                while($row2 = mysqli_fetch_array($result2))  {
            
            echo '
<img src="data:image/jpeg;base64,' .base64_encode($row2['ProfilePicture'] ).'" class="card-profile-img" />' ;
   
   
   }
   ?>
          </a>

          <h6 class="card-title">
            <a class="text-inherit" href="profile/index.html"><?php 
            echo $session_username;
            ?></a>
          </h6>

          <p class="mb-4"> <?php 
          
          echo $row["Bio"];
          ?>
          </p>

          <ul class="card-menu">
            <li class="card-menu-item">
              <a href="#userModal" class="text-inherit" data-toggle="modal">
                Friends
                <h6 class="my-0">
                    <?php
                     echo $row["Friends"];
                     
                    ?>
                    
                </h6>
              </a>
            </li>

            <li class="card-menu-item">
              <a href="#userModal" class="text-inherit" data-toggle="modal">
                Enemies
                <h6 class="my-0">
                    <?php
                    echo $row["Enemies"];
                    ?>
                    
                </h6>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div class="card visible-md-block visible-lg-block mb-4">
        <div class="card-block">
          <h6 class="mb-3">About <small>· <a href="#">Edit</a></small></h6>
          <ul class="list-unstyled list-spaced">
            <li><span class="text-muted icon icon-calendar mr-3"></span> Date Of Birth <a href="#">
                <?php   echo $row["DateOfBirth"] ; ?>
                
            </a>
            <li><span class="text-muted icon icon-users mr-3"></span>Relationship Status <a href="#"><?php 
            echo $row["Relationship_status"];
            ?></a>
            <li><span class="text-muted icon icon-github mr-3"></span>Hobbies <a href="#">
            <?php    echo $row["Hobbies"]  ?></a>
            <li><span class="text-muted icon icon-home mr-3"></span>Lives in <a href="#"><?php   
            echo $row["Lives_in"];
            ?></a>
            <li><span class="text-muted icon icon-location-pin mr-3"></span>From <a href="#">
                <?php echo $row["From_place"]; ?>
            </a>
          </ul>
        </div>
      </div>
 <?php
            }       }
    
    ?>
       <div class="card visible-md-block visible-lg-block">
        <div class="card-block">
          <h6 class="mb-3">Photos <small>· <a href="#">Edit</a></small></h6>
          <div data-grid="images" data-target-height="150">
              <?php
               $Username= $_SESSION["username"];
                $query = "SELECT * FROM All_Posts WHERE Username='$Username' ORDER BY Time DESC Limit 6 ";                
                $result = mysqli_query($connect, $query);  
                
                while($row = mysqli_fetch_array($result))  
                {
                    echo '<div>';

                 echo '<img src="data:image/jpeg;base64,' .base64_encode($row['Img'] ).'" height="640" width="640" /> ';
                 
                 echo '</div>';
                 
               
              ?>
          <?php
                }
          ?>
        </div>
      </div>
      </div>
      </div>
    

    <div class="col-lg-6">

      <ul class="list-group media-list media-list-stream mb-4">
<form enctype="multipart/form-data" METHOD="POST">
        <li class="media list-group-item p-4">
          <div class="input-group">
              
            <input type="text" class="form-control1"  name="Caption" id="Caption" placeholder="Caption" required>
            <div class="input-group-btn">
                
              <label for="image" class="btn btn-secondary1">
                            <span class="icon icon-camera"></span> <center>Add Picture</center>
           </label>
            <input id="image" name="image" type="file" required/>
            </div>
         <button class="btn btn-secondary1" name="insert" id="insert" value="Insert">Add Post</button>
          </div>
        </li>
</form>
            <div class="media-body">
            <div class="media-heading">
            <?php
            $Username= $_SESSION["username"];
                 $query2 = "SELECT * FROM All_Posts Order by Time Desc";  
                $result2 = mysqli_query($connect,$query2);
                 while($row2= mysqli_fetch_array($result2)) {
                    if($row2["Username"]== $Username){
                        
                    }else{
                    
   ?>
   <div class="media-body">
            <div class="media-heading">
        <li class="media list-group-item p-4">
            <?php
            $usernameofpost= $row2["Username"];
            $gettingpostprofilepicture="SELECT * FROM Information WHERE Username='$usernameofpost'";
            $result5 = mysqli_query($connect, $gettingpostprofilepicture); 
                while($row5 = mysqli_fetch_array($result5))  {
                                echo '<img src="data:image/jpeg;base64,' .base64_encode($row5['ProfilePicture'] ).'" class="media-object d-flex align-self-start mr-3" />' ;

                }
            
            ?>
          <div class="media-body">
            <div class="media-heading">
              <small class="float-right text-muted">
                  <?php 
                  echo $row2["Time"];
                  ?>
                  
              </small>
              <h6>
                  <?php
                  echo $row2["Username"];
                  ?>
                  
              </h6>
            </div>

            <p>
              <?php
              echo $row2["Text"];
              ?>
              
            </p>

            <div class="media-body-inline-grid" data-grid="images">
                
                <?php
               echo ' <img style="display: none" data-width="640" data-height="640" data-action="zoom" 
               src="data:image/jpeg;base64,' .base64_encode($row2['Img'] ).'">';
                ?>
                </div>
                <div>

                    <a class="likebutton" id="<?php  echo $row2['Id']?>" onclick="reply_click(this.id)">Like
                    </a>
                   <br><br>
                    <p><b> <?php echo $row2['Nooflikes']; ?> Likes</p></b>
                   </div>
                </div>
          </div>
        </li>
        <?php
                                }}
        ?>
      </ul>
    </div>
    <div class="col-lg-3">
      <div class="alert alert-warning alert-dismissible hidden-md-down" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <a class="alert-link" href="profile/index.html">Visit your profile!</a> Check your self, you aren't looking well.
      </div>



      <div class="card card-link-list">
        <div class="card-block">
© 2020 Dipit Golechha <br>
thanks for using the website :)
        </div>
      </div>
    </div>
  </div>
</div>

</div>
</div>
</div>
</div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/tether.min.js"></script>
    <script src="assets/js/chart.js"></script>
    <script src="assets/js/toolkit.js"></script>
    <script src="assets/js/application.js"></script>
    <script>
      // execute/clear BS loaders for docs
      $(function(){
        if (window.BS&&window.BS.loader&&window.BS.loader.length) {
          while(BS.loader.length){(BS.loader.pop())()}
        }
      })
    </script>
    
   
  </body>
</html>

